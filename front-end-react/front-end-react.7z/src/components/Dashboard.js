import Mercado from "./Mercado";
import "../css/style.css";

export default function Dashboard(){

    return (
        <div className="page">
            <Mercado/>
        </div>
        );
}